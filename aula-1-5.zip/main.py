n = int(input("qual a idade do nadador?"))

if n>=5 and n<=7:
  print("A categoria do nadador é Infatil A")

if n>=8 and n<=10:
  print("A categoria do nadador é Infantil B")

if n>=11 and n<=13:
  print("A categoria do nadador é Juvenil A")

if n>=14 and n<=17:
  print("A categoria do nadador é Juvenil B")

if n>=18:
  print("A categoria do nadador é Sênior")