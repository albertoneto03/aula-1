a = int(input("digite o primeiro numero"))
b = int(input("digite o segundo numero"))
c = int(input("digite o terceiro numero"))

if a>b>c:
  print(c,b,a)

if a>c>b:
  print(b,c,a)

if b>a>c:
  print(c,a,b)

if c>a>b:
  print(b,a,c)

if b>c>a:
  print(a,c,b)

if c>b>a:
  print(a,b,c)