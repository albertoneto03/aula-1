a = int(input("digite um numero"))
b = int(input("digite o segundo numero"))

if a+b>20:
  print(a+b+8)

else:
  print(a+b-5)