n = int(input("digite um numero"))

if n>0:
  print("Seu numero é Positivo")

if n==0:
  print("Seu numero é Neutro")

if n<0:
  print("Seu numero é Negativo")