n = int(input("digite o primeiro numero"))
m = int(input("digite o segundo numero"))
l = int(input("digite o terceiro numero"))

if n>m+l:
  print("O primeiro numero é maior que a soma dos outros dois")

if n<m+l:
  print("O primeiro numero é menor que a soma dos outros dois")

if n==m+l:
  print("O primeiro numero é igual a soma dos outros dois")
