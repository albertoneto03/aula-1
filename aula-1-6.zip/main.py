a = int(input("digite o primeiro numero"))
b = int(input("digite o segundo numero"))
c = int(input("digite o terceiro numero"))
d = int(input("digite o quarto numero"))
e = int(input("digite o quinto numero"))

if a>10 and b>10 and c>10 and d>10 and e>10:
  print("Cinco numeros são maiores que 10")

if a<=10 and b>10 and c>10 and d>10 and e>10 or a>10 and b<=10 and c>10 and d>10 and e>10 or a>10 and b>10 and c<=10 and d>10 and e>10 or a>10 and b>10 and c>10 and d<=10 and e>10 or a>10 and b>10 and c>10 and d>10 and e<=10:
  print("Quatro numeros são maiores que 10")

if a>10 and b>10 and c>10 and d<=10 and e<=10 or a>10 and b>10 and c<=10 and d>10 and e<=10 or a>10 and b<=10 and c>10 and d>10 and e<=10 or a<=10 and b>10 and c>10 and d>10 and e<=10 or a>10 and b>10 and c<=10 and d<=10 and e>10 or a>10 and b<=10 and c>10 and d<=10 and e>10 or a<=10 and b>10 and c>10 and d<=10 and e>10 or a>10 and b<=10 and c<=10 and d>10 and e>10 or a<=10 and b>10 and c<=10 and d>10 and e>10 or a<=10 and b<=10 and c>10 and d>10 and e>10:
  print("Três numeros são maiores que 10")

if a<=10 and b<=10 and c<=10 and d>10 and e>10 or a<=10 and b<=10 and c>10 and d<=10 and e>10 or a<=10 and b>10 and c<=10 and d<=10 and e>10 or a>10 and b<=10 and c<=10 and d<=10 and e>10 or a<=10 and b<=10 and c>10 and d>10 and e<=10 or a<=10 and b>10 and c<=10 and d>10 and e<=10 or a>10 and b<=10 and c<=10 and d>10 and e<=10 or a<=10 and b>10 and c>10 and d<=10 and e<=10 or a>10 and b<=10 and c>10 and d<=10 and e<=10 or a>10 and b>10 and c<=10 and d<=10 and e<=10:
  print("Dois numeros são maiores que 10")

if a<=10 and b<=10 and c<=10 and d<=10 and e>10 or a<=10 and b<=10 and c<=10 and d>10 and e<=10 or a<=10 and b<=10 and c>10 and d<=10 and e<=10 or a<=10 and b>10 and c<=10 and d<=10 and e<=10 or a>10 and b<=10 and c<=10 and d<=10 and e<=10:
  print("Um numero é maior que 10")

if a<=10 and b<=10 and c<=10 and d<=10 and e<=10:
  print("Os cinco numeros são menores que 10")