a = int(input("digite o primeiro numero"))
b = int(input("digite o segundo numero"))

if a>b:
  print(a-b)

else:
  print(b-a)